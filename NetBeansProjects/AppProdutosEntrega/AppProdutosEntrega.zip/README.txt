Projeto: AppProdutosEntrega
Pacotes:
- br.upf.ads.tde.dominio
- br.upf.ads.tde.front

Como compilar:
javac -d out src/br/upf/ads/tde/dominio/Produto.java src/br/upf/ads/tde/front/TelaProdutos.java

Como executar:
java -cp out br.upf.ads.tde.front.TelaProdutos
